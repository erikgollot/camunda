# Plugins Directory

Place plugins into this directory to extend the Camunda Modeler.


## Learn More

* [Example Plugins](https://github.com/camunda/camunda-modeler-plugins)
* [Plugins documentation](https://docs.camunda.io/docs/components/modeler/desktop-modeler/plugins/)
* [Plugin Starter Project](https://github.com/camunda/camunda-modeler-plugin-example)
